#  Intstructions for running A4
Enter Jupyter notebook to run A4Code.ipynb. Note that the notebook reads the models defined in models.py.
The notebook depends on Numpy, Matplotlib, Pandas and scipy
