#  Intstructions for running A5
Enter Jupyter notebook to run A5.ipynb.
The notebook depends on Numpy and Matplotlib
