#Assignment 2
to run assignment two, open the Jupyter notebook and run through the code.
Note that the code has been run on Tensorflow 0.12.1 with a GPU.
Additionally dependencies are Numpy 1.12.0, Pandas 0.19.2, and matplotlib 2.0.0

To change the dataset for the analysis, change line 4 accordingly.
