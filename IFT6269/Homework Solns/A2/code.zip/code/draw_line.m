function draw_line(beta,gamma,axis_boundaries);
% find two points on the line for drawing
xm = axis_boundaries(1);
xM = axis_boundaries(2);
ym = axis_boundaries(3);
yM = axis_boundaries(4);

if abs(beta(2))>1e-12
    % line is not vertical
p1 = [ xm, ( - gamma - beta(1) * xm ) / beta(2) ];
p2 = [ xM, ( - gamma - beta(1) * xM ) / beta(2) ];
else
    % line is close to vertical
    p1 = [  ( - gamma - beta(2) * ym ) / beta(1), ym ];
    p2 = [  ( - gamma - beta(2) * yM ) / beta(1), yM ];
end
plot([p1(1) p2(1)],[p1(2) p2(2)],'k-','linewidth',2);
