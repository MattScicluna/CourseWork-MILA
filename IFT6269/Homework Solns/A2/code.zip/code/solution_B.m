clear all
% load data
x = dlmread('classificationB.train');
y = x(:,3);
x = x(:,1:2);
xtest = dlmread('classificationB.test');
ytest = xtest(:,3);
xtest = xtest(:,1:2);

% LDA
% maximum likelihood estimation
N = length(y);
d = size(x,2);
n1 = sum(y);
n0 = N - n1;
pi = n1/N;
mu1 = 1/n1 * ( sum( repmat( y ,1,d ) .* x ) )';
mu0 = 1/n0 * ( sum( repmat( 1-y ,1,d ) .* x ) )';
xc1 = repmat( y ,1,d ) .* ( x - repmat( mu1', N , 1) ) ;      % centered data of class 1
xc0 = repmat( 1-y ,1,d ) .* ( x - repmat( mu0', N , 1) ) ;      % centered data of class 0

Sigma0 = 1/n0 * xc0' * xc0;
Sigma1 = 1/n1 * xc1' * xc1;
Sigma = n0/N * Sigma0 + n1/N * Sigma1;

% computing discriminative affine function
beta_LDA  = Sigma \ ( mu1 - mu0 );
gamma_LDA = - .5 * ( mu1 + mu0 )' * beta_LDA + log ( pi / ( 1 - pi) );

% compute error rates
error_train_LDA = mean( abs( ( sign( x * beta_LDA + gamma_LDA ) + 1 ) / 2 - y ) )
error_test_LDA = mean( abs( ( sign( xtest * beta_LDA + gamma_LDA ) + 1 ) / 2 - ytest ) )

% plotting data
subplot(2,2,1);
ind1 = find(y==1);
ind0 = find(y==0);
plot(x(ind1,1),x(ind1,2),'rx'); hold on
plot(x(ind0,1),x(ind0,2),'bo'); hold off

% plot line
axis_boundaries = [ -4 6 -5 5];  % minimal/maximal value of axis
axis(axis_boundaries);
hold on
draw_line(beta_LDA,gamma_LDA,axis_boundaries);
hold off
title('LDA','fontsize',16);
set(gca,'fontsize',16)

% LOGISTIC REGRESSION
x1 = [ x ones(N,1) ];   % add constant variable to x
theta = zeros(d+1,1);
normgradient = Inf;
k=1;
while normgradient > 1e-10
    eta = x1 * theta;
    mu = 1./(1+exp(-eta));
    gradient = x1'*(y-mu);
    % H = - x1' * diag( mu.*(1-mu) ) * x1 ;     % slow for large d
    H = - x1' * ( repmat( mu.*(1-mu) , 1 , d+1 ) .* x1 );
    % theta=theta-inv(H)*gradient;       % slower to compute the inverse
    theta = theta - H \ gradient;
    normgradient = norm(gradient);
    fprintf('k = %d - norm of gradient = %e\n',k,normgradient);
    k=k+1;
end
theta_LOGISTIC = theta;
beta_LOGISTIC = theta(1:d);
gamma_LOGISTIC = theta(d+1);

% compute error rates
error_train_LOGISTIC = mean( abs( ( sign( x * beta_LOGISTIC + gamma_LOGISTIC ) + 1 ) / 2 - y ) )
error_test_LOGISTIC = mean( abs( ( sign( xtest * beta_LOGISTIC + gamma_LOGISTIC ) + 1 ) / 2 - ytest ) )

% plotting data
subplot(2,2,2);
ind1 = find(y==1);
ind0 = find(y==0);
plot(x(ind1,1),x(ind1,2),'rx'); hold on
plot(x(ind0,1),x(ind0,2),'bo'); hold off

% plot line
axis_boundaries = [ -4 6 -5 5];  % minimal/maximal value of axis
axis(axis_boundaries);
hold on
draw_line(beta_LOGISTIC,gamma_LOGISTIC,axis_boundaries);
hold off
title('LOGISTIC','fontsize',16);
set(gca,'fontsize',16)





% LINEAR REGRESSION
x1 = [ x ones(N,1) ];   % add constant variable to x
theta = ( x1' * x1 ) \ ( x1' * y );

theta_LINEAREG = theta;
beta_LINEAREG = theta(1:d);
gamma_LINEAREG = theta(d+1) - .5;       % do not forget to remove .5

% compute error rates
error_train_LINEAREG = mean( abs( ( sign( x * beta_LINEAREG + gamma_LINEAREG ) + 1 ) / 2 - y ) )
error_test_LINEAREG = mean( abs( ( sign( xtest * beta_LINEAREG + gamma_LINEAREG ) + 1 ) / 2 - ytest ) )

% plotting data
subplot(2,2,3);
ind1 = find(y==1);
ind0 = find(y==0);
plot(x(ind1,1),x(ind1,2),'rx'); hold on
plot(x(ind0,1),x(ind0,2),'bo'); hold off

% plot line
axis_boundaries = [ -4 6 -5 5];  % minimal/maximal value of axis
axis(axis_boundaries);
hold on
draw_line(beta_LINEAREG,gamma_LINEAREG,axis_boundaries);
hold off
title('LINEAR REGRESSION','fontsize',16);
set(gca,'fontsize',16)







% QDA
% all parameters are already computed in the LDA section

Q_QDA = inv(Sigma0)-inv(Sigma1);
beta_QDA = Sigma1 \ mu1 - Sigma0 \ mu0;
gamma_QDA = .5 * mu0' * ( Sigma0 \ mu0 ) - .5 * mu1' * ( Sigma1 \ mu1 ) + log( pi/(1-pi) ) ...
    + .5 * sum( log( eig(Sigma0) ) ) -  .5 * sum( log( eig(Sigma1) ) );

% compute error rates
error_train_QDA = mean( abs( ( sign(  sum( .5 * ( x * Q_QDA) .* x , 2 ) + x * beta_QDA + gamma_QDA ) + 1 ) / 2 - y ) )
error_test_QDA = mean( abs( ( sign(  sum( .5 * ( xtest * Q_QDA) .* xtest , 2 ) + xtest * beta_QDA + gamma_QDA ) + 1 ) / 2 - ytest ) )

% plotting data
subplot(2,2,4);
ind1 = find(y==1);
ind0 = find(y==0);
plot(x(ind1,1),x(ind1,2),'rx'); hold on
plot(x(ind0,1),x(ind0,2),'bo'); hold off

% plot line
axis(axis_boundaries);
hold on
draw_conic(Q_QDA,beta_QDA,gamma_QDA);
hold off
title('QDA','fontsize',16);
set(gca,'fontsize',16)




FID = fopen('parameters_B.tex', 'w');
fprintf(FID,'\\subsubsection*{LDA}\n');
fprintf(FID,'$$');
print_matrix(FID,mu0,'pmatrix','\\mu_0= \n',[]);
print_matrix(FID,mu1,'pmatrix','\\quad \\mu_1= \n',[]);
print_matrix(FID,Sigma,'pmatrix','\\quad \\Sigma= \n',[]);
print_matrix(FID,beta_LDA,'pmatrix','\\quad \\beta= \n',[]);
fprintf(FID,'\\quad \\gamma=%8.2f \n',gamma_LDA);

fprintf(FID,'$$ \n');


fprintf(FID,'\\subsubsection*{R�gression logistique}\n');
fprintf(FID,'$$');
print_matrix(FID,beta_LOGISTIC,'pmatrix','\\beta= \n',[]);
fprintf(FID,'\\quad \\gamma=%8.2f \n',gamma_LOGISTIC);
fprintf(FID,'$$ \n');

fprintf(FID,'\\subsubsection*{R�gression lin�aire}\n');
fprintf(FID,'$$');
print_matrix(FID,beta_LINEAREG,'pmatrix','\\beta= \n',[]);
fprintf(FID,'\\quad \\gamma=%8.2f \n',gamma_LINEAREG);
fprintf(FID,'$$ \n');

fprintf(FID,'\\subsubsection*{QDA}\n');
fprintf(FID,'$$');
print_matrix(FID,mu0,'pmatrix','\\mu_0= \n',[]);
print_matrix(FID,mu1,'pmatrix','\\quad \\mu_1= \n',[]);
print_matrix(FID,Sigma0,'pmatrix','\\quad \\Sigma_0= \n',[]);
print_matrix(FID,Sigma1,'pmatrix','\\quad \\Sigma_1= \n',[]);
fprintf(FID,'$$ \n');

fprintf(FID,'$$');
print_matrix(FID,Q_QDA,'pmatrix','Q=',[]);
print_matrix(FID,beta_QDA,'pmatrix','\\quad \\beta= \n',[]);
fprintf(FID,'\\quad \\gamma=%8.2f \n',gamma_QDA);
fprintf(FID,'$$ \n');

fclose(FID);







