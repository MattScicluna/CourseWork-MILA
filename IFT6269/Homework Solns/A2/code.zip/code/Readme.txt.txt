1. Run solution_A.m to train all 4 algorithms with dataset A.
2. Run solution_B.m to train all 4 algorithms with dataset B.
3. Run solution_C.m to train all 4 algorithms with dataset C.

You should be able to run all these files in octave.