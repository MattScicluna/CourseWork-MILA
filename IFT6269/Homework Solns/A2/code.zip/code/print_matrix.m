function []=print_matrix(FID,M,mtype,prestring,filename)
do_close=false;
if isempty(FID),
    FID = fopen(filename, 'w');
    do_close=true;
end
[nrows,ncols]=size(M);
fprintf(FID,prestring);
switch mtype,
    case 'tabular'
        fprintf(FID, ['\\begin{tabular}{|' repmat('c',1,ncols) '|}\\hline \n']);
    case 'pmatrix'
        fprintf(FID,'\\begin{pmatrix}\n');
    case 'bmatrix'
        fprintf(FID,'\\begin{pmatrix}\n');
    otherwise
        fprintf(FID,'\\begin{matrix}\n');
end
for i=1:nrows,
    if ncols>1,
        fprintf(FID, '%8.2f &',M(i,1:end-1));
    end
    fprintf(FID, '%8.2f \\\\\n',M(i,end));
end

switch mtype,
    case 'tabular'
        fprintf(FID, '\\end{tabular}\n');
    case 'pmatrix'
        fprintf(FID,'\\end{pmatrix}\n');
    case 'bmatrix'
        fprintf(FID,'\\end{pmatrix}\n');
    otherwise
        fprintf(FID,'\\end{matrix}\n');
end
if do_close,
    fclose(FID);
end