function draw_ellipse( Q,beta,gamma)
[u,e] = eig(Q);
if prod(diag(e))<=0;
	% HYPERBOLE (two branches)
	if e(1) < 0 , Q = -Q ; beta = -beta; gamma = -gamma; e = -e; end % make sure e>0
	center = - Q \ beta;
	c =  - beta' * center - 2 * gamma;
	t = -10:.05:10;
	if c>0
		x =  sqrt(c/e(1,1)) * u(1,1) * cosh(t) + sqrt(-c/e(2,2)) * u(1,2) * sinh(t) + center(1);
		y =  sqrt(c/e(1,1)) * u(2,1) * cosh(t) + sqrt(-c/e(2,2)) * u(2,2) * sinh(t) + center(2);
		plot(x,y,'k-','linewidth',2);
		hold on;
		x =  -sqrt(c/e(1,1)) * u(1,1) * cosh(t) + sqrt(-c/e(2,2)) * u(1,2) * sinh(t) + center(1);
		y =  -sqrt(c/e(1,1)) * u(2,1) * cosh(t) + sqrt(-c/e(2,2)) * u(2,2) * sinh(t) + center(2);
		plot(x,y,'k-','linewidth',2);
		hold off;

	else
		x =  sqrt(-c/e(1,1)) * u(1,1) * sinh(t) + sqrt(c/e(2,2)) * u(1,2) * cosh(t) + center(1);
		y =  sqrt(-c/e(1,1)) * u(2,1) * sinh(t) + sqrt(c/e(2,2)) * u(2,2) * cosh(t) + center(2);
		plot(x,y,'k-','linewidth',2);
		hold on

		x =  sqrt(-c/e(1,1)) * u(1,1) * sinh(t) - sqrt(c/e(2,2)) * u(1,2) * cosh(t) + center(1);
		y =  sqrt(-c/e(1,1)) * u(2,1) * sinh(t) - sqrt(c/e(2,2)) * u(2,2) * cosh(t) + center(2);
		plot(x,y,'k-','linewidth',2);
		hold off

	end

else
	% ELLIPSE
	if e(1) < 0 , Q = -Q ; beta = -beta; gamma = -gamma; e = -e; end % make sure e>0
	center = - Q \ beta;
	c =  - beta' * center - 2 * gamma;
	t = (0:100) * 2*pi/100;
	x =  sqrt(c/e(1,1)) * u(1,1) * cos(t) + sqrt(c/e(2,2)) * u(1,2) * sin(t) + center(1);
	y =  sqrt(c/e(1,1)) * u(2,1) * cos(t) + sqrt(c/e(2,2)) * u(2,2) * sin(t) + center(2);
	plot(x,y,'k-','linewidth',2);
end