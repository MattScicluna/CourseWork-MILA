#The script is an R file. To run it in linux, use the following command
Rscript A1script.R
