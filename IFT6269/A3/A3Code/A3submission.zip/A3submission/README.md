#Assignment 3
to run assignment two, open the Jupyter notebook and run through the code.
Note that the code has been run on Tensorflow 0.12.1 with a GPU.
Additionally dependencies are Numpy 1.12.0, Pandas 0.19.2, and matplotlib 2.0.0, scipy and sklearn

The number of means, and iterations for kmeans and EM can be adjusted using NUM_MEANS, NUM_ITER and
NUM_ITER_EM respectively.

Note plotting will not work with # clusters different then 4.
